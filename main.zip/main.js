const mineflayer = require("mineflayer");
const gui = require("mineflayer-gui");
const inventoryViewer = require("mineflayer-web-inventory");
const readline = require("readline");

// Функция для ввода ника
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});

rl.question("Введите ник игрока: ", (username) => {
  const bot = mineflayer.createBot({
    host: "topbars.ru",
    port: 25565,
    username: username,
    auth: "offline",
    version: "1.20",
    physicsEnabled: false,
  });

  bot.loadPlugin(gui.plugin);
  inventoryViewer(bot);

  let messageCount = 0;
  let capchaPassed = false;
  let onBW = false;

  bot.on("message", (jsonMsg) => {
    let message = jsonMsg.json.extra.map((item) => item.text).join("");
    console.log(message);

    if (message.includes("⟹ Идет проверка, пожалуйста, подождите...")) {
      messageCount++;
      if (!bot.physicsEnabled && messageCount === 4) {
        bot.look(bot.entity.yaw + 22.23121, bot.entity.pitch + 42.3465);
        bot.physicsEnabled = true;
        bot.physics.gravity = 0.08;
      }
    }

    if (
      message.includes("Вы находитесь в Лобби") ||
      message.includes("Вы успешно вошли!")
    ) {
      capchaPassed = true;
      gotobedwars();
    }

    if (message.includes("Подключение к серверу bwlobby")) {
      onBW = true;
      setTimeout(() => {
        rejoin();
      }, 1000);
    }

    if (message.includes("Вы вернулись в игру!")) {
      spam();
    }
  });

  async function gotobedwars() {
    if (capchaPassed) {
      bot.chat("/reg _1234_ _1234_");
      bot.chat("/login _1234_");
      setTimeout(() => {
        bot.chat("/menu");
      }, 1000);

      bot.once("windowOpen", async (window) => {
        try {
          let bedSlot = window.slots.findIndex(
            (item) => item && item.name === "red_bed"
          );

          if (bedSlot !== -1) {
            console.log("Red bed found, clicking on it...");
            await bot.clickWindow(bedSlot, 0, 0);
            return;
          }

          console.log("Red bed not found, searching for pufferfish...");
          const pufferfishSlot = window.slots.findIndex(
            (item) => item && item.name === "pufferfish"
          );
          if (pufferfishSlot === -1)
            throw new Error("Pufferfish not found in menu");

          await bot.clickWindow(pufferfishSlot, 0, 0);

          bot.once("windowOpen", async (window) => {
            bedSlot = window.slots.findIndex(
              (item) => item && item.name === "red_bed"
            );
            if (bedSlot === -1)
              throw new Error("Red bed not found after clicking pufferfish");

            console.log(
              "Red bed found after clicking pufferfish, clicking on it..."
            );
            await bot.clickWindow(bedSlot, 0, 0);
          });
        } catch (err) {
          console.error("Error in gotobedwars:", err);
        }
      });
    }
  }

  function rejoin() {
    bot.chat("/rejoin");
  }

  function spam() {
    setInterval(() => {
      bot.chat("!Взломан by PidorClient");
    }, 5000);
  }

  bot.on("kicked", console.log);

  rl.close();
});
